function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  colorMode(RGB,255,255,255);
  color(255,0,0);
  fill(255,0,0);
  stroke(20);
  strokeWeight(10);
  line(mouseX, mouseY, pmouseX, pmouseY);
  angleMode(RADIANS);
  dist(mouseX, mouseY, pmouseX, pmouseY);
  frameRate(60);
}